<div class="banner">
  <div class="welcome_msg">
    <h1>Today's Inspiration</h1>
    <p>
      A recipe has no SOUL <br>
      YOU, as the cook must bring <br>
      the SOUL to the recipe. <br>
      <span>~ Thomas Keller</span>
    </p>
    <a class="btn" href="register.php">Join us!</a>
  </div>
  <div class="login_div">
    <form action="index.php" method="post">
      <h2>Login</h2>
      <input type="text" name="username" placeholder="Username">
      <input type="password" name="password" placeholder="Password">
      <button class="btn" type="submit" name="login_btn">Sign in</button>
    </form>
  </div>
</div>


