<div class="footer">
  <p>MyFood Blog &copy; <?php echo date('Y'); ?></p>
</div>


